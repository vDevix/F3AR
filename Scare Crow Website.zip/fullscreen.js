let isFullScreen = false;
let lastKeyPressTime = 0;

document.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        toggleFullScreen();
    } else if (e.key === 'q') {
        handleQKeyPress();
    }
});

function toggleFullScreen() {
    const elem = document.documentElement;

    if (!isFullScreen) {
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) {  // Firefox
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) {  // Chrome, Safari and Opera
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) {  // IE/Edge
            elem.msRequestFullscreen();
        }

        isFullScreen = true;
    }
}

function handleQKeyPress() {
    const currentTime = new Date().getTime();
    const timeDifference = currentTime - lastKeyPressTime;

    if (timeDifference < 200) {
        exitFullScreen();
    } else {
        lastKeyPressTime = currentTime;
    }
}

function exitFullScreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {  // Firefox
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {  // Chrome, Safari and Opera
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {  // IE/Edge
        document.msExitFullscreen();
    }

    isFullScreen = false;
}